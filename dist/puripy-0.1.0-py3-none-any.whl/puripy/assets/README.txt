# Place your logo file (e.g., logo.png) in this directory.
puripy\assets\logo.png